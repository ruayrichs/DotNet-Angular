export class SuperHero {
    id?: number;
    name = "";
    firstName = "";
    lastName = "";
    place = "";
}